#include <iostream>
#include <armadillo>
#include <math.h>   // This gives INFINITY

#ifdef __cplusplus 
extern "C" {
#endif
    /* Declarations of this file */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <signal.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

#include "adcdriver_host.h"
#include "spidriver_host.h"
#ifdef __cplusplus
}
#endif


using namespace std;
using namespace arma;

const float pi = 3.1415926535897932384;
#define NUM_FRAMES 100
#define NUM_PTS 1024
fvec x[NUM_PTS];
// Stuff used with "hit return when ready..." 
char dummy[8];

void music_estimate(fvec *v_pointer, float fsamp);
float music_sum(float f, fmat V);
float cross_type_product(cx_fvec cv, fvec dv);


int main(int argc, char** argv){
	
  // Initialize A/D converter
  adc_config();
  adc_set_samplerate(SAMP_RATE_31250);
	 
  
  printf("--------------------------------------------------\n");
  printf("Now read training set: %d data frames\n", NUM_FRAMES);
  printf("Hit return when ready -->\n");
  
  
  //fgets (dummy, 8, stdin);
  adc_read_multiple(NUM_PTS, (float*)x); 
  /*
    fvec x;
    for(int i=0; i<sizeof(volts); i++){
    x(i) = volts[i];
    }
  */
  float fsamp = 31250;
  
  
  
  
  //create a time fvector of a signal;
  /*
    int Nx = 136;
    int Tmax = 13;
    fvec t = linspace(0,Tmax*(Nx-1)/Nx, Nx); // t is col fvector
    cout << "T is" << t << endl;
    float dt;
    dt = t(1) - t(0);
    float fsamp = 1/dt;
    float f0 = 2.0;
    fvec x;
    
    x = sin(2*pi*f0*t); // x is col fvector
  */
  
  //cout << "x is" << x << endl;
  
  
  music_estimate(x,fsamp);
}


void music_estimate(fvec *v_pointer, float fsamp){
	int M;
	// Create a reference 
	fvec v = *v_pointer;
	
	M = v.size(); // M = size(v,0);
	int p = 2;
	
		
	// Covariance matrix
	fmat Rxx;
	Rxx = v * v.t();
	// svd decomp
	fmat U; fmat V; fvec s;
	svd(U,s,V,Rxx);
	
	// Save the noise fvector in V
	fmat Vnoise = V.cols(p+1, size(V,1)-1);
	
	// Loop over all frequencies
	int Nf = 3001;
	fvec f = linspace<fvec>(0.0f, fsamp/2.0f, Nf);
	
	// Pmu is 3001x1.
	fmat Pmu = zeros<fvec>(Nf, 1); // size(.) returns a 2d size but .size() return 1d
	
	for(int i = 0; i < Nf; i++){
		Pmu(i) = music_sum(f(i)/fsamp, Vnoise);
	}
	// here comes the figure 2;
	
	uvec idxM = zeros<uvec>(Nf);
	fvec Pcol;
	for(int i=0; i<size(Pmu,1); i++){
	  Pcol = Pmu.col(i);
	  // Find index of max value of Pcol
	  float elt = -INFINITY;
	  int maxj = 0;
	  for (int j=0; j<Nf; j++) {
	    if (Pcol(j) > elt) {
	      maxj = j;
	      elt = Pcol(j);
	    }
	  }
	  idxM(i) = maxj;
	}
	
	fvec f0(idxM.size());
	for(int i = 0; i< f0.size(); i++){
		f0(i) = f(idxM(i));
	}
	
	cout << scientific;
	cout << "Estimated frequency is " << f0(0) << endl;
	
	
}

float music_sum(float f, fmat V){
	
	int Mr = size(V,0);
	cx_fvec e(Mr);
	cx_fvec e0(Mr);
	
	float idx = 0;
	for(int i = 0; i<Mr; i++){
		e0(i) = cx_float(0.0, 2*pi*idx*f);
		idx += 1;
	}
	e = exp(e0);
	
	int Mc = size(V,1);
	float s = 0;
	float ele = 0;
	for(int i = 0; i<Mc; i++){
		//t = e.as_row() * V.col(i);
		//s += abs(t)*abs(t);
		// Instead of jumping to the complex math， 
		// we define a new function to do the complex product
		ele = cross_type_product(e,V.col(i));
		s += ele * ele;
	}
	
	float p = 1/s;
	return p;	
}


float cross_type_product(cx_fvec cv, fvec dv){
	// We want to get cv * dv
	// We first split the complex fvector to two real fvecotors(real & imag parts)
	// Then do the product in real math
	
	
	float re;
	float im;
	frowvec cv_re(cv.size()); // real part of the complex fvector
	frowvec cv_im(cv.size()); // imaginary part of the complex fvector
	for(int i =0; i<cv.size(); i++){
		re = cv(i).real(); // extract the real part
		im = cv(i).imag(); // extract the imaginary part
		cv_re(i) = re;
		cv_im(i) = im;	
	}
	cx_float s = cx_float(0,0); // Define a new complex number to 
								  // save the results of the multip
	for(int i =0; i<cv.size(); i++){
		s += cx_float(cv_re(i)*dv(i),cv_im(i)*dv(i));
	}
	// Norm of the complex number 
	float rel = norm(s);
	
	return rel;
}
